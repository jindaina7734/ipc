﻿using LiveCharts;
using LiveCharts.Wpf;
using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace ReadFromPLC
{
    public partial class MainWindow : Window
    {
        private TcpClient client;
        private NetworkStream stream;
        private bool isReading;

        public ChartValues<double> ChartValues { get; set; }
        public ObservableCollection<string> TimeLabels { get; set; }
        public ObservableCollection<string> LogEntries { get; set; }
        public double MinThreshold { get; set; } = 22000; // Minimum threshold

        private const string LogFilePath = "PLC_Log.csv"; // Path

        public MainWindow()
        {
            InitializeComponent();

            // Khoi tao chart va log entries
            ChartValues = new ChartValues<double>();
            TimeLabels = new ObservableCollection<string>();
            LogEntries = new ObservableCollection<string>();

            // Bind data vao UI
            lineChart.DataContext = this;
            logListBox.ItemsSource = LogEntries;
        }

        private void btnConnect_Click(object sender, RoutedEventArgs e)
        {
            string ipAddress = txtIPAddress.Text;
            int port = int.Parse(txtPort.Text);

            try
            {
                client = new TcpClient(ipAddress, port);
                stream = client.GetStream();
                MessageBox.Show("Connected successfully!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Connection failed: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private async void btnStartReading_Click(object sender, RoutedEventArgs e)
        {
            if (stream == null || !stream.CanRead)
            {
                MessageBox.Show("Not connected to PLC.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            isReading = true;
            txtStatus.Text = "Status: Reading...";
            txtStatus.Foreground = Brushes.Green;

            string address = txtAddress.Text;

            await Task.Run(() =>
            {
                while (isReading)
                {
                    try
                    {
                        // Gui lenh read
                        string command = $"RD {address}\r\n";
                        byte[] commandBytes = Encoding.ASCII.GetBytes(command);
                        stream.Write(commandBytes, 0, commandBytes.Length);

                        // Tra ve lenh read
                        byte[] buffer = new byte[1024];
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);
                        string response = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                        // Chuyen response ve dang so thuc
                        if (double.TryParse(response, out double value))
                        {
                            string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); // Timestamp format
                            string logEntry;

                            // Update UI
                            Dispatcher.Invoke(() =>
                            {
                                // Update gia tri trong chart
                                ChartValues.Add(value);

                                // Update thoi gian 
                                TimeLabels.Add(timestamp);

                                // Xu ly cac du lieu < threshold
                                if (value < MinThreshold)
                                {
                                    logEntry = $"{timestamp},{value},Below Minimum Threshold"; // Log entry format
                                    LogEntries.Add($"{timestamp}: {value} - Below Minimum Threshold!");
                                }
                                else
                                {
                                    logEntry = $"{timestamp},{value},OK"; // Log entry format
                                    LogEntries.Add($"{timestamp}: {value}");
                                }

                                // Write to CSV log
                                WriteToCsv(logEntry);

                                // So luong du lieu trong 1 chart hay log entries
                                if (ChartValues.Count > 40) //doi voi chart
                                {
                                    ChartValues.RemoveAt(0);
                                    TimeLabels.RemoveAt(0);
                                }

                                if (LogEntries.Count > 50) //doi voi log entries
                                {
                                    LogEntries.RemoveAt(0);
                                }
                            });
                        }

                        // Thoi gian delay moi lan doc du lieu (1000ms = 1s)
                        Task.Delay(1000).Wait();
                    }
                    catch (Exception ex)
                    {
                        string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"); // Timestamp format
                        string logEntry = $"{timestamp},ERROR,{ex.Message}"; // Log entry format for errors

                        Dispatcher.Invoke(() =>
                        {
                            MessageBox.Show($"Error reading data: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                            txtStatus.Text = "Status: Error";
                            txtStatus.Foreground = Brushes.Red;

                            // Log error
                            LogEntries.Add($"{timestamp}: ERROR - {ex.Message}");
                            WriteToCsv(logEntry);
                        });

                        isReading = false;
                    }
                }
            });

            txtStatus.Text = "Status: Idle";
            txtStatus.Foreground = Brushes.Gray;
        }

        private void btnDisconnect_Click(object sender, RoutedEventArgs e)
        {
            isReading = false;
            txtStatus.Text = "Status: Disconnected";
            txtStatus.Foreground = Brushes.Gray;

            if (stream != null) stream.Close();
            if (client != null) client.Close();
            MessageBox.Show("Disconnected!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void WriteToCsv(string logEntry)
        {
            try
            {
                // Check if the file exists
                bool fileExists = File.Exists(LogFilePath);

                using (StreamWriter writer = new StreamWriter(LogFilePath, true))
                {
                    // If the file does not exist, write the header
                    if (!fileExists)
                    {
                        writer.WriteLine("Timestamp,Value,Status"); // Header row
                    }

                    // Write the log entry
                    writer.WriteLine(logEntry);
                }
            }
            catch (Exception ex)
            {
                Dispatcher.Invoke(() =>
                {
                    MessageBox.Show($"Error writing to log file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                });
            }
        }
    }
}
